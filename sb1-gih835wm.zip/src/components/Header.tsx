import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';

export function Header() {
  const { user, logout } = useAuth();
  const { getTotalItems } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="bg-white shadow-lg border-b-2 border-orange-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2 group">
            <img 
              src="/public/WhatsApp Image 2025-09-25 at 14.04.01_4559d04a.jpg" 
              alt="Ubuntu Flame Grill Logo" 
              className="h-12 w-12 object-contain group-hover:scale-105 transition-transform"
            />
            <div>
              <h1 className="text-xl font-bold text-gray-900">Ubuntu Flame Grill</h1>
              <p className="text-xs text-gray-600">Flame-grilled perfection</p>
            </div>
          </Link>

          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/menu" className="text-gray-700 hover:text-orange-600 font-medium transition-colors">
              Menu
            </Link>
            <Link to="/about" className="text-gray-700 hover:text-orange-600 font-medium transition-colors">
              About
            </Link>
            <Link to="/contact" className="text-gray-700 hover:text-orange-600 font-medium transition-colors">
              Contact
            </Link>
            {user?.role === 'customer' && (
              <Link to="/orders" className="text-gray-700 hover:text-orange-600 font-medium transition-colors">
                My Orders
              </Link>
            )}
          </nav>

          <div className="flex items-center space-x-4">
            {user?.role === 'customer' && (
              <Link to="/cart" className="relative p-2 text-gray-700 hover:text-orange-600 transition-colors">
                <ShoppingCart className="h-6 w-6" />
                {getTotalItems() > 0 && (
                  <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {getTotalItems()}
                  </span>
                )}
              </Link>
            )}

            {user ? (
              <div className="flex items-center space-x-2">
                {user.role === 'admin' && (
                  <Link to="/admin" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                    Dashboard
                  </Link>
                )}
                {user.role === 'delivery' && (
                  <Link to="/delivery" className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                    Delivery
                  </Link>
                )}
                {user.role === 'staff' && (
                  <Link to="/staff" className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                    Kitchen
                  </Link>
                )}
                <div className="flex items-center space-x-2 text-gray-700">
                  <User className="h-5 w-5" />
                  <span className="font-medium">{user.name}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="p-2 text-gray-500 hover:text-red-600 transition-colors"
                  title="Logout"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Link to="/login" className="px-4 py-2 text-orange-600 border border-orange-600 rounded-lg hover:bg-orange-50 transition-colors">
                  Login
                </Link>
                <Link to="/register" className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
                  Sign Up
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}