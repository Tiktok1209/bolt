import React from 'react';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  text?: string;
}

export function LoadingSpinner({ size = 'md', text }: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: 'h-6 w-6',
    md: 'h-8 w-8',
    lg: 'h-12 w-12'
  };

  return (
    <div className="flex flex-col items-center justify-center space-y-3">
      <div className="relative">
        <div className={`${sizeClasses[size]} animate-spin rounded-full border-2 border-orange-200`}>
          <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-orange-600"></div>
        </div>
        <div className="absolute inset-0 flex items-center justify-center">
          <img 
            src="/public/WhatsApp Image 2025-09-25 at 14.04.01_4559d04a.jpg" 
            alt="Ubuntu Flame Grill Logo" 
            className={`${size === 'sm' ? 'h-3 w-3' : size === 'md' ? 'h-4 w-4' : 'h-6 w-6'} object-contain`}
          />
        </div>
      </div>
      {text && (
        <p className={`text-gray-600 ${size === 'sm' ? 'text-sm' : 'text-base'}`}>
          {text}
        </p>
      )}
    </div>
  );
}