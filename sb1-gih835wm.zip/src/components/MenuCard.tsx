import React from 'react';
import { Plus, ShoppingCart } from 'lucide-react';
import { MenuItem } from '../types';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

interface MenuCardProps {
  item: MenuItem;
}

export function MenuCard({ item }: MenuCardProps) {
  const { addItem } = useCart();
  const { user } = useAuth();

  const handleAddToCart = () => {
    if (!user || user.role !== 'customer') {
      toast.error('Please login as a customer to add items to cart');
      return;
    }
    
    addItem(item);
    toast.success(`${item.name} added to cart!`);
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 group">
      <div className="relative h-48 overflow-hidden">
        <img
          src={item.image_url || 'https://images.pexels.com/photos/70497/pexels-photo-70497.jpeg'}
          alt={item.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-4 right-4">
          <span className="bg-orange-500 text-white px-2 py-1 rounded-full text-sm font-semibold">
            {item.category}
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-gray-900 group-hover:text-orange-600 transition-colors">
            {item.name}
          </h3>
          <span className="text-2xl font-bold text-orange-600">
            R{item.price.toFixed(2)}
          </span>
        </div>
        
        <p className="text-gray-600 mb-4 leading-relaxed">
          {item.description}
        </p>
        
        <div className="flex items-center justify-between">
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
            item.available 
              ? 'bg-green-100 text-green-800' 
              : 'bg-red-100 text-red-800'
          }`}>
            {item.available ? 'Available' : 'Sold Out'}
          </span>
          
          <button
            onClick={handleAddToCart}
            disabled={!item.available || !user || user.role !== 'customer'}
            className="bg-orange-600 hover:bg-orange-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white px-6 py-2 rounded-lg flex items-center space-x-2 transition-all duration-200 group transform hover:scale-105"
          >
            <Plus className="h-4 w-4 group-hover:rotate-90 transition-transform" />
            <span>Add to Cart</span>
          </button>
        </div>
      </div>
    </div>
  );
}