import React from 'react';
import { Clock, ChefHat, CheckCircle, Truck, MapPin, XCircle } from 'lucide-react';

interface OrderStatusBadgeProps {
  status: string;
  size?: 'sm' | 'lg';
}

export function OrderStatusBadge({ status, size = 'sm' }: OrderStatusBadgeProps) {
  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'pending':
        return {
          icon: Clock,
          text: 'Pending',
          bgColor: 'bg-yellow-100',
          textColor: 'text-yellow-800',
          iconColor: 'text-yellow-600',
        };
      case 'confirmed':
        return {
          icon: CheckCircle,
          text: 'Confirmed',
          bgColor: 'bg-blue-100',
          textColor: 'text-blue-800',
          iconColor: 'text-blue-600',
        };
      case 'preparing':
        return {
          icon: ChefHat,
          text: 'Preparing',
          bgColor: 'bg-orange-100',
          textColor: 'text-orange-800',
          iconColor: 'text-orange-600',
        };
      case 'ready':
        return {
          icon: CheckCircle,
          text: 'Ready',
          bgColor: 'bg-green-100',
          textColor: 'text-green-800',
          iconColor: 'text-green-600',
        };
      case 'out_for_delivery':
        return {
          icon: Truck,
          text: 'Out for Delivery',
          bgColor: 'bg-purple-100',
          textColor: 'text-purple-800',
          iconColor: 'text-purple-600',
        };
      case 'delivered':
        return {
          icon: MapPin,
          text: 'Delivered',
          bgColor: 'bg-green-100',
          textColor: 'text-green-800',
          iconColor: 'text-green-600',
        };
      case 'cancelled':
        return {
          icon: XCircle,
          text: 'Cancelled',
          bgColor: 'bg-red-100',
          textColor: 'text-red-800',
          iconColor: 'text-red-600',
        };
      default:
        return {
          icon: Clock,
          text: 'Unknown',
          bgColor: 'bg-gray-100',
          textColor: 'text-gray-800',
          iconColor: 'text-gray-600',
        };
    }
  };

  const config = getStatusConfig(status);
  const Icon = config.icon;

  return (
    <span className={`inline-flex items-center ${size === 'lg' ? 'px-4 py-2 text-base' : 'px-2.5 py-0.5 text-xs'} rounded-full font-medium ${config.bgColor} ${config.textColor}`}>
      <Icon className={`${size === 'lg' ? 'h-5 w-5 mr-2' : 'h-3 w-3 mr-1'} ${config.iconColor}`} />
      {config.text}
    </span>
  );
}