import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: Partial<User> & { password: string }) => Promise<boolean>;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem('ubuntu_grill_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setLoading(true);
      
      // Mock authentication - replace with actual Supabase auth
      if (email === 'admin@ubuntu-grill.com' && password === 'admin123') {
        const adminUser: User = {
          id: '1',
          email: 'admin@ubuntu-grill.com',
          name: 'Admin User',
          role: 'admin',
          created_at: new Date().toISOString(),
        };
        setUser(adminUser);
        localStorage.setItem('ubuntu_grill_user', JSON.stringify(adminUser));
        return true;
      }
      
      if (email === 'delivery@ubuntu-grill.com' && password === 'delivery123') {
        const deliveryUser: User = {
          id: '2',
          email: 'delivery@ubuntu-grill.com',
          name: 'Delivery Staff',
          role: 'delivery',
          created_at: new Date().toISOString(),
        };
        setUser(deliveryUser);
        localStorage.setItem('ubuntu_grill_user', JSON.stringify(deliveryUser));
        return true;
      }
      
      if (email === 'staff@ubuntu-grill.com' && password === 'staff123') {
        const staffUser: User = {
          id: '3',
          email: 'staff@ubuntu-grill.com',
          name: 'Kitchen Staff',
          role: 'staff',
          created_at: new Date().toISOString(),
        };
        setUser(staffUser);
        localStorage.setItem('ubuntu_grill_user', JSON.stringify(staffUser));
        return true;
      }
      
      // Default customer login
      const customerUser: User = {
        id: email,
        email,
        name: email.split('@')[0],
        role: 'customer',
        created_at: new Date().toISOString(),
      };
      setUser(customerUser);
      localStorage.setItem('ubuntu_grill_user', JSON.stringify(customerUser));
      return true;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const register = async (userData: Partial<User> & { password: string }): Promise<boolean> => {
    try {
      setLoading(true);
      
      // Mock registration - replace with actual Supabase auth
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        email: userData.email!,
        name: userData.name!,
        phone: userData.phone,
        address: userData.address,
        role: 'customer',
        created_at: new Date().toISOString(),
      };
      
      setUser(newUser);
      localStorage.setItem('ubuntu_grill_user', JSON.stringify(newUser));
      return true;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('ubuntu_grill_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}