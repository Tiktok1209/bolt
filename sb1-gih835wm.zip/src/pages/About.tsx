import React from 'react';
import { Users, Award, Clock, MapPin, Phone, Mail, Flame } from 'lucide-react';

export function About() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-orange-600 to-red-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-24 h-24 bg-white bg-opacity-20 backdrop-blur-sm rounded-full mb-6 p-2">
              <img 
                src="/public/WhatsApp Image 2025-09-25 at 14.04.01_4559d04a.jpg" 
                alt="Ubuntu Flame Grill Logo" 
                className="w-full h-full object-contain"
              />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">About Ubuntu Flame Grill</h1>
            <p className="text-xl md:text-2xl text-orange-100 max-w-3xl mx-auto">
              Bringing authentic South African flavors to your table since 2020
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  Ubuntu Flame Grill was born from a passion for authentic South African cuisine and the 
                  spirit of Ubuntu - the belief that we are all connected through our shared humanity.
                </p>
                <p>
                  Founded in 2020, we started as a small family business with a simple mission: to bring 
                  the rich, flame-grilled flavors of South Africa to food lovers everywhere. Our recipes 
                  have been passed down through generations, each dish telling a story of tradition, 
                  culture, and love.
                </p>
                <p>
                  Today, we continue to honor these traditions while embracing modern convenience through 
                  our online ordering platform, ensuring that authentic South African cuisine is just a 
                  click away.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg"
                alt="Our kitchen"
                className="rounded-xl shadow-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Flame className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Authenticity</h3>
              <p className="text-gray-600">
                Every dish is prepared using traditional South African recipes and cooking methods, 
                ensuring authentic flavors in every bite.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Ubuntu Spirit</h3>
              <p className="text-gray-600">
                We believe in the Ubuntu philosophy - "I am because we are." Our success is built on 
                community, connection, and caring for one another.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Award className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Quality</h3>
              <p className="text-gray-600">
                We source only the finest ingredients and maintain the highest standards in food 
                preparation and customer service.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Meet Our Team</h2>
            <p className="text-xl text-gray-600">
              The passionate people behind Ubuntu Flame Grill
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl shadow-md p-6 text-center">
              <div className="w-24 h-24 bg-gradient-to-r from-orange-500 to-red-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-white text-2xl font-bold">TM</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Thabo Mthembu</h3>
              <p className="text-orange-600 font-semibold mb-3">Head Chef & Founder</p>
              <p className="text-gray-600 text-sm">
                With over 15 years of culinary experience, Thabo brings authentic South African 
                flavors to every dish.
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-md p-6 text-center">
              <div className="w-24 h-24 bg-gradient-to-r from-green-500 to-blue-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-white text-2xl font-bold">NM</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Nomsa Mbeki</h3>
              <p className="text-green-600 font-semibold mb-3">Operations Manager</p>
              <p className="text-gray-600 text-sm">
                Nomsa ensures every order meets our high standards and that our customers 
                receive exceptional service.
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-md p-6 text-center">
              <div className="w-24 h-24 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-white text-2xl font-bold">SK</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Sipho Khumalo</h3>
              <p className="text-purple-600 font-semibold mb-3">Customer Experience Lead</p>
              <p className="text-gray-600 text-sm">
                Sipho leads our customer service team, ensuring every interaction reflects 
                our Ubuntu values.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}