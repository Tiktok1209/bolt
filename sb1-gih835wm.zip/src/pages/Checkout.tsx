import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Clock, MessageSquare, ArrowRight } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

export function Checkout() {
  const navigate = useNavigate();
  const { items, getTotalPrice } = useCart();
  const { user } = useAuth();
  
  const [orderDetails, setOrderDetails] = useState({
    orderType: 'delivery',
    deliveryAddress: user?.address || '',
    notes: '',
    deliveryTime: 'asap'
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setOrderDetails(prev => ({ ...prev, [name]: value }));
  };

  const handleProceedToPayment = () => {
    if (orderDetails.orderType === 'delivery' && !orderDetails.deliveryAddress.trim()) {
      toast.error('Please enter a delivery address');
      return;
    }

    navigate('/payment', { state: { orderDetails } });
  };

  if (!user || items.length === 0) {
    navigate('/cart');
    return null;
  }

  const totalAmount = getTotalPrice();
  const deliveryFee = orderDetails.orderType === 'delivery' ? 25.00 : 0;
  const finalTotal = totalAmount + deliveryFee;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h1 className="text-2xl font-bold text-gray-900">Checkout</h1>
            <p className="text-gray-600">Review your order and delivery details</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 p-6">
            {/* Order Details Form */}
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Order Type
                </label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setOrderDetails(prev => ({ ...prev, orderType: 'delivery' }))}
                    className={`p-4 border-2 rounded-lg text-center transition-colors ${
                      orderDetails.orderType === 'delivery'
                        ? 'border-orange-500 bg-orange-50 text-orange-700'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <MapPin className="h-6 w-6 mx-auto mb-2" />
                    <span className="font-medium">Delivery</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderDetails(prev => ({ ...prev, orderType: 'takeaway' }))}
                    className={`p-4 border-2 rounded-lg text-center transition-colors ${
                      orderDetails.orderType === 'takeaway'
                        ? 'border-orange-500 bg-orange-50 text-orange-700'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <Clock className="h-6 w-6 mx-auto mb-2" />
                    <span className="font-medium">Takeaway</span>
                  </button>
                </div>
              </div>

              {orderDetails.orderType === 'delivery' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Delivery Address
                  </label>
                  <textarea
                    name="deliveryAddress"
                    value={orderDetails.deliveryAddress}
                    onChange={handleInputChange}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Enter your full delivery address..."
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Delivery Time
                </label>
                <select
                  name="deliveryTime"
                  value={orderDetails.deliveryTime}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                >
                  <option value="asap">As soon as possible</option>
                  <option value="30min">In 30 minutes</option>
                  <option value="1hour">In 1 hour</option>
                  <option value="2hours">In 2 hours</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Special Instructions
                </label>
                <textarea
                  name="notes"
                  value={orderDetails.notes}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Any special requests or dietary requirements..."
                />
              </div>
            </div>

            {/* Order Summary */}
            <div className="bg-gray-50 rounded-lg p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h2>
              
              <div className="space-y-3 mb-4">
                {items.map((item, index) => (
                  <div key={index} className="flex justify-between">
                    <div>
                      <p className="font-medium text-gray-900">{item.menuItem.name}</p>
                      <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                      {item.customization && (
                        <p className="text-sm text-orange-600">Note: {item.customization}</p>
                      )}
                    </div>
                    <span className="font-medium">R{(item.menuItem.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-gray-200 pt-4 space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>R{totalAmount.toFixed(2)}</span>
                </div>
                {orderDetails.orderType === 'delivery' && (
                  <div className="flex justify-between">
                    <span>Delivery Fee</span>
                    <span>R{deliveryFee.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>Total</span>
                  <span className="text-orange-600">R{finalTotal.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={handleProceedToPayment}
                className="w-full mt-6 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white py-3 px-6 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-all duration-300"
              >
                <span>Proceed to Payment</span>
                <ArrowRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}