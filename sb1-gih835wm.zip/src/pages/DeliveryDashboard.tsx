import React, { useState } from 'react';
import { MapPin, Clock, CheckCircle, Navigation, Phone } from 'lucide-react';
import { OrderStatusBadge } from '../components/OrderStatusBadge';
import { mockOrders } from '../data/mockData';
import toast from 'react-hot-toast';

export function DeliveryDashboard() {
  const [orders, setOrders] = useState(
    mockOrders.filter(order => order.order_type === 'delivery' && ['ready', 'out_for_delivery'].includes(order.status))
  );

  const handlePickup = (orderId: string) => {
    setOrders(prev => prev.map(order =>
      order.id === orderId ? { ...order, status: 'out_for_delivery' as any, updated_at: new Date().toISOString() } : order
    ));
    toast.success('Order marked as picked up');
  };

  const handleDelivered = (orderId: string) => {
    setOrders(prev => prev.map(order =>
      order.id === orderId ? { ...order, status: 'delivered' as any, updated_at: new Date().toISOString() } : order
    ));
    toast.success('Order marked as delivered');
  };

  const openMaps = (address: string) => {
    const encodedAddress = encodeURIComponent(address);
    window.open(`https://www.google.com/maps/search/${encodedAddress}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Delivery Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage your delivery orders</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Ready for Pickup</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {orders.filter(order => order.status === 'ready').length}
                </p>
              </div>
              <div className="bg-orange-500 p-3 rounded-lg">
                <Clock className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Out for Delivery</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {orders.filter(order => order.status === 'out_for_delivery').length}
                </p>
              </div>
              <div className="bg-blue-500 p-3 rounded-lg">
                <Navigation className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completed Today</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">12</p>
              </div>
              <div className="bg-green-500 p-3 rounded-lg">
                <CheckCircle className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* Orders List */}
        <div className="bg-white rounded-xl shadow-md">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-900">Active Deliveries</h2>
          </div>

          <div className="divide-y divide-gray-200">
            {orders.map((order) => (
              <div key={order.id} className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                  <div className="flex-1">
                    <div className="flex items-center space-x-4 mb-3">
                      <h3 className="text-lg font-semibold text-gray-900">Order #{order.id}</h3>
                      <OrderStatusBadge status={order.status} />
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium text-gray-700 mb-1">Customer</p>
                        <p className="text-gray-900">{order.customer.name}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Phone className="h-4 w-4 text-gray-500" />
                          <span className="text-sm text-gray-600">{order.customer.phone}</span>
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-sm font-medium text-gray-700 mb-1">Delivery Address</p>
                        <div className="flex items-start space-x-2">
                          <MapPin className="h-4 w-4 text-gray-500 mt-1 flex-shrink-0" />
                          <span className="text-sm text-gray-600">{order.delivery_address}</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3">
                      <p className="text-sm font-medium text-gray-700 mb-1">Order Details</p>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Total: R{order.total_amount.toFixed(2)}</span>
                        <span className="text-sm text-gray-500">
                          Ordered {new Date(order.created_at).toLocaleTimeString()}
                        </span>
                      </div>
                      {order.notes && (
                        <p className="text-sm text-orange-600 mt-1">Note: {order.notes}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row lg:flex-col space-y-2 sm:space-y-0 sm:space-x-2 lg:space-x-0 lg:space-y-2 lg:ml-6">
                    <button
                      onClick={() => openMaps(order.delivery_address)}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center justify-center space-x-2 transition-colors"
                    >
                      <Navigation className="h-4 w-4" />
                      <span>Navigate</span>
                    </button>
                    
                    {order.status === 'ready' && (
                      <button
                        onClick={() => handlePickup(order.id)}
                        className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg transition-colors"
                      >
                        Mark as Picked Up
                      </button>
                    )}
                    
                    {order.status === 'out_for_delivery' && (
                      <button
                        onClick={() => handleDelivered(order.id)}
                        className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
                      >
                        Mark as Delivered
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {orders.length === 0 && (
            <div className="p-12 text-center">
              <Navigation className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No active deliveries</h3>
              <p className="text-gray-600">All deliveries are up to date!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}