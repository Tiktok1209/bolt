import React, { useState } from 'react';
import { Clock, CheckCircle, Truck, MapPin, Star, MessageSquare, CreditCard as Edit } from 'lucide-react';
import { OrderStatusBadge } from '../components/OrderStatusBadge';
import { useAuth } from '../contexts/AuthContext';
import { mockOrders } from '../data/mockData';
import toast from 'react-hot-toast';

export function Orders() {
  const { user } = useAuth();
  const [selectedOrder, setSelectedOrder] = useState<string | null>(null);
  const [showReviewModal, setShowReviewModal] = useState<string | null>(null);
  const [reviewData, setReviewData] = useState({ rating: 5, feedback: '' });
  const [showAddressModal, setShowAddressModal] = useState(false);
  const [newAddress, setNewAddress] = useState(user?.address || '');

  // Filter orders for current user (in a real app, this would come from the database)
  const userOrders = mockOrders.filter(order => order.customer_id === user?.id);

  const handleRateOrder = (orderId: string, rating: number) => {
    setShowReviewModal(orderId);
    setReviewData({ rating, feedback: '' });
  };

  const submitReview = () => {
    if (!reviewData.feedback.trim()) {
      toast.error('Please provide feedback');
      return;
    }
    
    // In a real app, this would submit to the database
    toast.success('Thank you for your review!');
    setShowReviewModal(null);
    setReviewData({ rating: 5, feedback: '' });
  };

  const updateAddress = () => {
    if (!newAddress.trim()) {
      toast.error('Please enter a valid address');
      return;
    }
    
    // In a real app, this would update the user's address in the database
    toast.success('Delivery address updated successfully!');
    setShowAddressModal(false);
  };

  if (!user || user.role !== 'customer') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600">Please login as a customer to view your orders.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">My Orders</h1>
            <p className="text-gray-600 mt-2">Track your order history and current deliveries</p>
          </div>
          <button
            onClick={() => setShowAddressModal(true)}
            className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
          >
            <Edit className="h-4 w-4" />
            <span>Update Address</span>
          </button>
        </div>

        {userOrders.length === 0 ? (
          <div className="bg-white rounded-xl shadow-md p-12 text-center">
            <Clock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">No Orders Yet</h2>
            <p className="text-gray-600 mb-6">You haven't placed any orders yet. Start exploring our menu!</p>
            <a
              href="/menu"
              className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-lg transition-colors"
            >
              Browse Menu
            </a>
          </div>
        ) : (
          <div className="space-y-6">
            {userOrders.map((order) => (
              <div key={order.id} className="bg-white rounded-xl shadow-md overflow-hidden">
                <div className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">
                    <div>
                      <div className="flex items-center space-x-4 mb-2">
                        <h3 className="text-xl font-bold text-gray-900">Order #{order.id}</h3>
                        <OrderStatusBadge status={order.status} size="lg" />
                      </div>
                      <p className="text-gray-600">
                        Placed on {new Date(order.created_at).toLocaleDateString()} at{' '}
                        {new Date(order.created_at).toLocaleTimeString()}
                      </p>
                    </div>
                    <div className="text-right mt-4 lg:mt-0">
                      <p className="text-2xl font-bold text-orange-600">
                        R{order.total_amount.toFixed(2)}
                      </p>
                      <p className="text-sm text-gray-600 capitalize">
                        {order.order_type} • {order.payment_status}
                      </p>
                    </div>
                  </div>

                  {/* Order Details */}
                  <div className="border-t border-gray-200 pt-4">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Delivery Information</h4>
                        <div className="flex items-start space-x-2">
                          <MapPin className="h-5 w-5 text-gray-500 mt-1" />
                          <span className="text-gray-600">{order.delivery_address}</span>
                        </div>
                      </div>
                      
                      {order.notes && (
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2">Special Instructions</h4>
                          <p className="text-gray-600">{order.notes}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Order Actions */}
                  <div className="border-t border-gray-200 pt-4 mt-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-3 sm:space-y-0">
                      <button
                        onClick={() => setSelectedOrder(selectedOrder === order.id ? null : order.id)}
                        className="text-orange-600 hover:text-orange-800 font-medium"
                      >
                        {selectedOrder === order.id ? 'Hide Details' : 'View Details'}
                      </button>
                      
                      <div className="flex space-x-3">
                        {order.status === 'delivered' && (
                          <div className="flex items-center space-x-1">
                            <span className="text-sm text-gray-600">Rate this order:</span>
                            {[1, 2, 3, 4, 5].map((rating) => (
                              <button
                                key={rating}
                                onClick={() => handleRateOrder(order.id, rating)}
                                className="text-gray-300 hover:text-yellow-400 transition-colors"
                              >
                                <Star className="h-5 w-5" />
                              </button>
                            ))}
                          </div>
                        )}
                        
                        <button className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                          Reorder
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Order Details */}
                  {selectedOrder === order.id && (
                    <div className="border-t border-gray-200 pt-4 mt-4">
                      <h4 className="font-semibold text-gray-900 mb-4">Order Items</h4>
                      <div className="space-y-3">
                        {/* Mock order items - in a real app, these would come from order_items table */}
                        <div className="flex items-center justify-between py-2">
                          <div className="flex items-center space-x-3">
                            <img
                              src="https://cdn.pixabay.com/photo/2022/08/31/10/17/burger-7422970_1280.jpg"
                              alt="Ubuntu Flame Burger"
                              className="w-12 h-12 object-cover rounded-lg"
                            />
                            <div>
                              <p className="font-medium text-gray-900">Ubuntu Flame Burger</p>
                              <p className="text-sm text-gray-600">Qty: 2</p>
                            </div>
                          </div>
                          <span className="font-semibold text-gray-900">R170.00</span>
                        </div>
                        
                        <div className="flex items-center justify-between py-2">
                          <div className="flex items-center space-x-3">
                            <img
                              src="https://grumblesa.co.za/wp-content/uploads/2024/06/How-to-Make-a-Kota-Business-Successful.jpg"
                              alt="Kota"
                              className="w-12 h-12 object-cover rounded-lg"
                            />
                            <div>
                              <p className="font-medium text-gray-900">Kota</p>
                              <p className="text-sm text-gray-600">Qty: 1</p>
                            </div>
                          </div>
                          <span className="font-semibold text-gray-900">R49.99</span>
                        </div>
                      </div>
                      
                      <div className="border-t border-gray-200 pt-3 mt-4">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-gray-900">Total</span>
                          <span className="text-xl font-bold text-orange-600">
                            R{order.total_amount.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Review Modal */}
        {showReviewModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Rate Your Order</h3>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Rating</label>
                <div className="flex items-center space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setReviewData(prev => ({ ...prev, rating: star }))}
                      className={`h-8 w-8 ${
                        star <= reviewData.rating
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-300'
                      } hover:text-yellow-400 transition-colors`}
                    >
                      <Star className="h-full w-full" />
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Feedback</label>
                <textarea
                  value={reviewData.feedback}
                  onChange={(e) => setReviewData(prev => ({ ...prev, feedback: e.target.value }))}
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Tell us about your experience..."
                />
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowReviewModal(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={submitReview}
                  className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                >
                  Submit Review
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Address Update Modal */}
        {showAddressModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Update Delivery Address</h3>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">New Address</label>
                <textarea
                  value={newAddress}
                  onChange={(e) => setNewAddress(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="Enter your full delivery address..."
                />
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowAddressModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={updateAddress}
                  className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                >
                  Update Address
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}