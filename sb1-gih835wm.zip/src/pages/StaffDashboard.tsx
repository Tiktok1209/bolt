import React, { useState } from 'react';
import { Clock, CheckCircle, ChefHat, AlertCircle } from 'lucide-react';
import { OrderStatusBadge } from '../components/OrderStatusBadge';
import { mockOrders } from '../data/mockData';
import toast from 'react-hot-toast';

export function StaffDashboard() {
  const [orders, setOrders] = useState(
    mockOrders.filter(order => ['pending', 'confirmed', 'preparing'].includes(order.status))
  );

  const handleMarkReady = (orderId: string) => {
    setOrders(prev => prev.map(order =>
      order.id === orderId ? { ...order, status: 'ready' as any, updated_at: new Date().toISOString() } : order
    ));
    toast.success('Order marked as ready!');
  };

  const handleStartPreparing = (orderId: string) => {
    setOrders(prev => prev.map(order =>
      order.id === orderId ? { ...order, status: 'preparing' as any, updated_at: new Date().toISOString() } : order
    ));
    toast.success('Order preparation started!');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Kitchen Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage order preparation and completion</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending Orders</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {orders.filter(order => order.status === 'pending').length}
                </p>
              </div>
              <div className="bg-yellow-500 p-3 rounded-lg">
                <Clock className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">In Preparation</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {orders.filter(order => order.status === 'preparing').length}
                </p>
              </div>
              <div className="bg-orange-500 p-3 rounded-lg">
                <ChefHat className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completed Today</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">24</p>
              </div>
              <div className="bg-green-500 p-3 rounded-lg">
                <CheckCircle className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* Orders List */}
        <div className="bg-white rounded-xl shadow-md">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-900">Active Orders</h2>
          </div>

          <div className="divide-y divide-gray-200">
            {orders.map((order) => (
              <div key={order.id} className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                  <div className="flex-1">
                    <div className="flex items-center space-x-4 mb-3">
                      <h3 className="text-lg font-semibold text-gray-900">Order #{order.id}</h3>
                      <OrderStatusBadge status={order.status} />
                      <span className="text-sm text-gray-500">
                        {new Date(order.created_at).toLocaleTimeString()}
                      </span>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium text-gray-700 mb-1">Customer</p>
                        <p className="text-gray-900">{order.customer.name}</p>
                        <p className="text-sm text-gray-600">{order.order_type}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm font-medium text-gray-700 mb-1">Order Total</p>
                        <p className="text-lg font-bold text-orange-600">R{order.total_amount.toFixed(2)}</p>
                      </div>
                    </div>

                    {/* Order Items */}
                    <div className="mt-4">
                      <p className="text-sm font-medium text-gray-700 mb-2">Items to Prepare</p>
                      <div className="bg-gray-50 rounded-lg p-3">
                        {/* Mock order items - in a real app, these would come from order_items table */}
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="font-medium">Ubuntu Flame Burger</span>
                            <span className="text-sm bg-orange-100 text-orange-800 px-2 py-1 rounded">x2</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="font-medium">Kota</span>
                            <span className="text-sm bg-orange-100 text-orange-800 px-2 py-1 rounded">x1</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {order.notes && (
                      <div className="mt-3">
                        <p className="text-sm font-medium text-gray-700 mb-1">Special Instructions</p>
                        <p className="text-sm text-orange-600 bg-orange-50 p-2 rounded">{order.notes}</p>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col space-y-2 lg:ml-6">
                    {order.status === 'pending' && (
                      <button
                        onClick={() => handleStartPreparing(order.id)}
                        className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg transition-colors"
                      >
                        Start Preparing
                      </button>
                    )}
                    
                    {order.status === 'preparing' && (
                      <button
                        onClick={() => handleMarkReady(order.id)}
                        className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
                      >
                        Mark as Ready
                      </button>
                    )}
                    
                    <button className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors">
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {orders.length === 0 && (
            <div className="p-12 text-center">
              <ChefHat className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No active orders</h3>
              <p className="text-gray-600">All orders are up to date!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}