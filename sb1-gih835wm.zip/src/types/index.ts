export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  address?: string;
  role: 'customer' | 'admin' | 'delivery' | 'staff';
  created_at: string;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image_url?: string;
  available: boolean;
  created_at: string;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  customization?: string;
}

export interface Order {
  id: string;
  customer_id: string;
  customer: User;
  delivery_address: string;
  order_type: 'delivery' | 'takeaway';
  status: 'pending' | 'confirmed' | 'preparing' | 'ready' | 'out_for_delivery' | 'delivered' | 'cancelled';
  payment_status: 'pending' | 'paid' | 'failed';
  payment_method?: string;
  total_amount: number;
  delivery_staff_id?: string;
  delivery_staff?: User;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  menu_item_id: string;
  menu_item: MenuItem;
  quantity: number;
  customization?: string;
  unit_price: number;
}

export interface Review {
  id: string;
  order_id: string;
  customer_id: string;
  customer: User;
  rating: number;
  feedback: string;
  created_at: string;
}

export interface SalesData {
  daily_total: number;
  weekly_total: number;
  monthly_total: number;
  total_orders: number;
  pending_orders: number;
  completed_orders: number;
}